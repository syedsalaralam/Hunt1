# Arrow Hunt 🏹

A modern, interactive arrow hunting game with an elegant purple neon aesthetic. Test your precision and reflexes as you track flying birds and shoot arrows to hunt them down before they escape.

## Features

- 🎮 **Interactive Gameplay** - Track birds with cursor, click to shoot arrows
- 🎯 **Progressive Difficulty** - Game gets harder every 5 hits with faster birds and more spawns
- 💜 **Purple Neon Design** - Modern UI with glowing purple aesthetic and blur effects
- 🔊 **Sound Effects** - Immersive Web Audio API effects with mute toggle
- 🖥️ **Fullscreen Mode** - Play in immersive fullscreen experience
- 📱 **Fully Responsive** - Works seamlessly on all device sizes
- ⚡ **No Backend Required** - Pure static front-end, easily deployable

## Game Rules

- **Objective**: Hunt as many birds as possible before 10 escape
- **Scoring**: Each successful hit = 10 points
- **Difficulty Scaling**: After every 5 hits, birds become faster and spawn more frequently
- **Game Over**: When 10 birds escape without being hunted
- **Controls**: Move mouse to position archer, click anywhere to shoot

## Tech Stack

- **Frontend**: React 18 + React Router 6 (SPA)
- **Build Tool**: Vite
- **Styling**: Tailwind CSS 3
- **Language**: TypeScript
- **Testing**: Vitest
- **UI Components**: Radix UI + Lucide Icons

## Getting Started

### Prerequisites

- Node.js 16+ 
- pnpm (recommended) or npm/yarn

### Local Development

1. **Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/arrow-hunt.git
cd arrow-hunt
```

2. **Install dependencies**
```bash
pnpm install
# or: npm install / yarn install
```

3. **Start development server**
```bash
pnpm dev
# or: npm run dev / yarn dev
```

The app will be available at `http://localhost:5173`

### Build for Production

```bash
pnpm build
# or: npm run build / yarn build
```

This creates optimized production builds in the `dist/` directory.

### Run Production Build Locally

```bash
pnpm start
# or: npm start / yarn start
```

### Type Checking

```bash
pnpm typecheck
# or: npm run typecheck / yarn typecheck
```

### Testing

```bash
pnpm test
# or: npm test / yarn test
```

## Project Structure

```
arrow-hunt/
├── client/                          # React frontend
│   ├── components/
│   │   ├── GameArena.tsx           # Main game component with game logic
│   │   └── ui/                     # Reusable UI components
│   ├── pages/
│   │   ├── Index.tsx               # Home page with game and guides
│   │   └── NotFound.tsx            # 404 page
│   ├── hooks/                      # Custom React hooks
│   ├── lib/
│   │   └── utils.ts                # Utility functions
│   ├── App.tsx                     # App routing setup
│   ├── global.css                  # Global styles & theme variables
│   └── vite-env.d.ts              # Vite environment types
├── server/                         # Express server (if needed)
│   ├── index.ts                   # Server setup
│   └── routes/                    # API routes
├── shared/                         # Shared types between client & server
│   └── api.ts                     # API interfaces
├── public/                         # Static assets
├── package.json                    # Dependencies & scripts
├── tsconfig.json                   # TypeScript config
├── vite.config.ts                  # Vite config
├── tailwind.config.ts             # Tailwind CSS config
├── .gitignore                      # Git ignore rules
└── vercel.json                     # Vercel deployment config
```

## Deployment

### Deploy to Vercel (Recommended)

The easiest way to deploy is with [Vercel](https://vercel.com):

1. **Push to GitHub**
```bash
git push origin main
```

2. **Connect to Vercel**
   - Go to https://vercel.com
   - Click "New Project"
   - Import your GitHub repository
   - Vercel will auto-detect the configuration
   - Click "Deploy"

The app will be live at a Vercel URL immediately, and automatically redeploys on every push to main.

### Deploy to Netlify

1. **Build the project**
```bash
pnpm build
```

2. **Connect to Netlify**
   - Go to https://netlify.com
   - Click "New site from Git"
   - Select your GitHub repository
   - Build command: `pnpm build`
   - Publish directory: `dist`
   - Click "Deploy"

### Deploy Anywhere Else

Since this is a static site (no backend API required), you can deploy to any static hosting:

- **GitHub Pages**
- **AWS S3 + CloudFront**
- **Google Cloud Storage**
- **Azure Static Web Apps**
- **Firebase Hosting**

Just run `pnpm build` and upload the `dist/` folder.

## Environment Variables

This app doesn't require any environment variables. The `.env` file is included in `.gitignore` to prevent accidental commits of sensitive data.

## Game Mechanics

### Archer
- Stands fixed at the bottom center of the game arena
- Position doesn't move during gameplay
- Automatically aims toward your cursor position

### Birds
- Fly from left to right across the screen
- Appear in the upper 40% of the game area
- Speed increases with difficulty level
- Multiple birds spawn simultaneously at higher levels

### Arrows
- Travel from archer's position toward cursor
- Collision detection with birds
- Remove automatically when off-screen

### Scoring
- **Hit**: +10 points + sound effect
- **Miss**: Counts toward 10-miss game over limit
- **Levels**: Increase every 5 hits (birds get faster, more spawn)

## Browser Compatibility

- Chrome/Edge: ✅ Full support
- Firefox: ✅ Full support
- Safari: ✅ Full support
- Mobile browsers: ✅ Full support (responsive design)

## Audio Features

- **Web Audio API** for sound generation
- **Bird Hunt Sound**: Descending frequency when you hit a bird
- **Background Sound**: Playing when game starts
- **Toggle**: Mute/unmute button in bottom-right corner
- Works across all modern browsers

## Responsive Design

- **Desktop** (≥1024px): 75% width game arena + full page content
- **Tablet** (768px-1023px): 83% width game arena
- **Mobile** (<768px): Full width responsive layout
- **Fullscreen Mode**: 100% viewport coverage for immersive play

## Historical Inspiration

The game draws inspiration from:
- **Ancient Greek Archery Competitions** - Historical contests showcasing skill and precision
- **Traditional Hunting** - Ancient practice of tracking and hunting moving targets
- **Archery Evolution** - From hunting tool to refined competitive art form across cultures

## Contributing

Feel free to fork and create pull requests for any improvements!

## License

This project is open source and available under the MIT License.

## Support

For issues or questions:
- Check the [GitHub Issues](https://github.com/YOUR_USERNAME/arrow-hunt/issues)
- Create a new issue with detailed description

## Future Enhancements

Potential features for future versions:
- Leaderboard with local storage
- Different game modes (time-based, target-based)
- Power-ups and special effects
- Multiplayer mode
- Mobile touch controls optimization
- Sound effects library instead of generated tones

---

**Built with ❤️ using React, TypeScript, Tailwind CSS, and Vite**
